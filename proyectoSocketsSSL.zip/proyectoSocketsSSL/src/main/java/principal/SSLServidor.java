package principal;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.SSLServerSocketFactory;
import javax.swing.JOptionPane;

public class SSLServidor {

    private ServerSocket serverSocket;
    private ServerSocket server = null;
    private Socket socket = null;
    DataInputStream entrar;
    DataOutputStream salir;
    String leerMensaje = "";
    String conversacion = "";
    int i = 0;

    public SSLServidor(int port) throws IOException {
        SSLServerSocketFactory serverFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        serverSocket = serverFactory.createServerSocket(port);
    }






   public void start() {
      Conexiones.startServerWorking(serverSocket);
   }
 
}