package principal;

import java.io.IOException;

/**
 * Example with SSL sockets using system properties.
 */
public class probarCodigo {
   public static void main(String[] args) throws IOException {
      System.setProperty("javax.net.ssl.keyStore", "src/main/certs/server/serverKey.jks");
      System.setProperty("javax.net.ssl.keyStorePassword","servpass");
      System.setProperty("javax.net.ssl.trustStore", "src/main/certs/client/clientTrustedCerts.jks");
      System.setProperty("javax.net.ssl.trustStorePassword", "clientpass");
      
   
    new SSLServidor(2010).start();
   new SSLCliente("localhost",2010).start();
        


     
   }
}
