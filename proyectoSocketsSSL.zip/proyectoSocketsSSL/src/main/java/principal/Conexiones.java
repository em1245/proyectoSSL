package principal;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

public class Conexiones {
    static DataInputStream entrar ;
     static DataOutputStream salir;
      static DataInputStream entrar2 ;
     static DataOutputStream salir2;
      static String conversacion = "";
       static String conversacion2 = "";
      static String leerMensaje="";
      static int i =0;
         static int j =0;
   public static void startClientWorking(final Socket client){
       

        
      System.out.println("client start");
    
      new Thread() {
          
         public void run() {
             Socket cliente = client;
            while(true){
                 entrar = null;
                 salir = null;
                 conversacion ="";
                 i++;
                 
            try {
               
                  entrar = new DataInputStream(cliente.getInputStream());
                salir = new DataOutputStream(cliente.getOutputStream());
                String m = JOptionPane.showInputDialog(null, "Escribe mensaje desde el cliente:");
                salir.writeUTF(m);
                String mensaje = entrar.readUTF();
                System.out.println("Servidor num  " + i + ": " + mensaje);
                conversacion+= "\nCliente: "+m+"\nServidor: "+mensaje;
                JOptionPane.showMessageDialog(null,conversacion);
               // cliente.close();
               
                /*
               PrintWriter output = new PrintWriter(client.getOutputStream());
               output.println("esto es una prueba");
               output.flush();
               System.out.println("hola jajaj");
               BufferedReader input = new BufferedReader(new InputStreamReader(
                     client.getInputStream()));
               String received = input.readLine();
               System.out.println("Received : " + received);
               client.close();
              */    
                
                
                
                
                
            } catch (IOException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
         }
      }.start();
       
       }
   
   
   public static void startServerWorking(final ServerSocket serverSocket) {
       
      System.out.println("server start");
      new Thread() {
         public void run() {
            try {
                /*
               Socket aClient = serverSocket.accept();
               System.out.println("cliente aceptado");
               aClient.setSoLinger(true, 1000);
               BufferedReader input = new BufferedReader(new InputStreamReader(
                     aClient.getInputStream()));
               String recibido = input.readLine();
               System.out.println("Recibido " + recibido);
               PrintWriter output = new PrintWriter(aClient.getOutputStream());
               output.println("quet tal, " + recibido);
               output.flush();
               aClient.close();
               */
               
               
                j++;
             Socket socket = serverSocket.accept();
                entrar2 = new DataInputStream(socket.getInputStream());
                salir2 = new DataOutputStream(socket.getOutputStream());
                leerMensaje = entrar2.readUTF(); //mensaje del cliente
                System.out.println("Mensaje num " + j + " del CLIENTE: " + leerMensaje);
                String mensaje = JOptionPane.showInputDialog(null, "escribe mensaje desde el servidor:");
                salir2.writeUTF(mensaje);
                conversacion2+="\nServidor: "+mensaje+"\nCliente: "+leerMensaje;
                  JOptionPane.showMessageDialog(null,conversacion2);
            
               
               
               
            } catch (Exception e) {
               e.printStackTrace();
            }

         }
      }.start();
   }

}
